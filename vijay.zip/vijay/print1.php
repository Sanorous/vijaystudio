<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv='Content-Type' content='text/html; charset=UTF-8' />
	
	<title>Editable Invoice</title>
	
	<link rel='stylesheet' type='text/css' href='css/style1.css' />
	<link rel='stylesheet' type='text/css' href='css/print1.css' media="print" />
	<script type='text/javascript' src='js/jquery-1.3.2.min.js'></script>
	<script type='text/javascript' src='js/example1.js'></script>

</head>

<body>

<?php
require("db.php");
$id =$_REQUEST['Id'];
$result = mysql_query("SELECT * FROM client WHERE Id  = '$id'");
$test = mysql_fetch_array($result);
if (!$result) 
		{
		die("Error: Data not found..");
		}
				$Id= $test['Id'];
				$Name= $test['Name'] ;
				$Mobile= $test['Mobile'] ;
				$Email= $test['Email'] ;
                $Address= $test['Address'] ;
                $Date= $test['Date'] ;
                $Occasion= $test['Occasion'] ;
                $Occasion_date= $test['Occasion_date'] ;
                $Time= $test['Time'] ;
                $Venue= $test['Venue'] ;
                $Occasion1= $test['Occasion1'] ;
                $Occasion_date1= $test['Occasion_date1'] ;
                $Time1= $test['Time1'] ;
                $Venue1= $test['Venue1'] ;
                $Occasion2= $test['Occasion2'] ;
                $Occasion_date2= $test['Occasion_date2'] ;
                $Time2= $test['Time2'] ;
                $Venue2= $test['Venue2'] ;
                $Occasion3= $test['Occasion3'] ;
                $Occasion_date3= $test['Occasion_date3'] ;
                $Time3= $test['Time3'] ;
                $Venue3= $test['Venue3'] ;
                $Occasion4= $test['Occasion4'] ;
                $Occasion_date4= $test['Occasion_date4'] ;
                $Time4= $test['Time4'] ;
                $Venue4= $test['Venue4'] ;
                $Total= $test['Total'] ;
                $Advance= $test['Advance'] ;
                $Balance= $test['Balance'] ;
                $Others= $test['Others'] ;
                                			
if(isset($_POST['save']))
{	
	$Name_save = $_POST['Name'];
	$Designation_save = $_POST['Designation'];
	$Dob_save = $_POST['Dob'];
	$Employer_save = $_POST['Employer'];
	$Mobile_save = $_POST['Mobile'];
	$other_save = $_POST['other'];

	mysql_query("UPDATE form SET Name ='$Name_save', Designation ='$Designation_save', Dob ='$Dob_save', Employer='$Employer_save', Mobile='$Mobile_save', other='$other_save' WHERE UserId = '$id'")
				or die(mysql_error()); 
	echo "Saved!";
	header("Location: clients.php");			
}
mysql_close($conn);
?>


	<div id="page-wrap">

		<textarea id="header">INVOICE</textarea>
		
		<div id="identity">
		
            <textarea id="address">9-A New Janpath Complex
Opp Income Tax Office
Hazratganj, Lucknow.

Phone: +91 9450 525252</textarea>

            <div id="logo">

              
              <div id="logohelp">
                <input id="imageloc" type="text" size="50" value="" /><br />
                (max width: 540px, max height: 100px)
              </div>
              <img id="image" src="images/logo1.png" alt="logo" />
            </div>
		
		</div>
		
		<div style="clear:both"></div>
		
		<div id="customer">

            <textarea id=""><?php echo $Name ?>
             <?php echo $Address ?></textarea>

            <table id="meta">
                <tr>
                    <td class="meta-head">Invoice #</td>
                    <td><!--<textarea>-->00<?php echo $Id ?><!--</textarea>--></td>
                </tr>
                <tr>

                    <td class="meta-head">Date</td>
                    <td><?php echo $Date ?></td>
                </tr>
                <tr>
                    <td class="meta-head">Amount Due</td>
                    <td><div class="due">Rs.<?php echo $Balance ?></div></td>
                </tr>

            </table>
		
		</div>
		
		<table id="items">
		
		  <tr>
		      <th>Occasion</th>
		      <th>Date</th>
		      <th>Venue</th>
		      <th>Time</th>
		  </tr>
		  
		  <tr class="item-row">
		      <td class="item-name"><?php echo $Occasion ?></td>
		      <td class="description"><?php echo $Occasion_date ?></td>
		      <td class="cost"><?php echo $Venue ?></td>
		      <td class="qty"><?php echo $Time ?></td>
		      
		  </tr>
		  
		  <tr class="item-row">
		      <td class="item-name"><?php echo $Occasion1 ?></td>
		      <td class="description"><?php echo $Occasion_date1 ?></td>
		      <td class="cost"><?php echo $Venue1 ?></td>
		      <td class="qty"><?php echo $Time1 ?></td>
		      
		  </tr>
		  
		  <tr class="item-row">
		      <td class="item-name"><?php echo $Occasion2 ?></td>
		      <td class="description"><?php echo $Occasion_date2 ?></td>
		      <td class="cost"><?php echo $Venue2 ?></td>
		      <td class="qty"><?php echo $Time2 ?></td>
		  </tr>
		  
		  <tr class="item-row">
		      <td class="item-name"><?php echo $Occasion3 ?></td>
		      <td class="description"><?php echo $Occasion_date3 ?></td>
		      <td class="cost"><?php echo $Venue3 ?></td>
		      <td class="qty"><?php echo $Time3 ?></td>
		  </tr>
		  
		  <tr class="item-row">
		      <td class="item-name"><?php echo $Occasion4 ?></td>
		      <td class="description"><?php echo $Occasion_date4 ?></td>
		      <td class="cost"><?php echo $Venue4 ?></td>
		      <td class="qty"><?php echo $Time4 ?></td>
		  </tr>
		  </table>
		  
		  <br />
		  
		  <table id="meta">
                <tr>
                    <td class="meta-head">Total</td>
                    <td><!--<textarea>-->Rs. <?php echo $Total ?><!--</textarea>--></td>
                </tr>
                <tr>

                    <td class="meta-head">Advance</td>
                    <td>Rs. <?php echo $Advance ?></td>
                </tr>
                <tr>
                    <td class="meta-head">Amount Due</td>
                    <td><div class="due">Rs. <?php echo $Balance ?></div></td>
                </tr>

            </table>
            <br />
            <br />
            <br />
            <br />
            <br />
            <br /> 
		
		<div id="">
		  <h3 style="text-align:center">Terms & Conditions</h3>
		 <p>1. 20% of Total amount should be given at the time of Booking. 50% should be given on the day of Occasion and the left 30% will be given on delivering the data. </p>
		 <p>2. 100% of LCD, Crane and Wall TV charges will be given at the time of booking.</p>
		 <p>3. Data should be taken within 2 months else there will be no responsibility of studio. </p>
		 <p>4. No responsibilities of studio for Digital Camera and Video Camera technical issues </p>
		 <p>5. Convenience Charges for venue will be given by Client.</p>
		 <p>6. All sorts of disputes will be subject to Lucknow High Court.</p>
		 <p>7. During the programme, Photographer and his instruments responsibility will be of Client. </p>
		 <p>8. During the uses of arms in programme, camera will be off.</p>
		 <p>9. Photos and data will not be given in Pen Drive.</p>
		</div>
	
	</div>
	
</body>

</html>